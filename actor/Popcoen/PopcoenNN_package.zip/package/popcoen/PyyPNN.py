from __future__ import division
from __future__ import print_function

import datetime
import hashlib
import itertools as it
import os
import random
import string
import time

import numpy as np
import theano
from future.builtins import map
from future.builtins import range
from future.builtins import zip
from six import print_
from sklearn.model_selection import KFold

from theano import tensor as T
from theano.misc.pkl_utils import dump
from theano.sandbox.rng_mrg import MRG_RandomStreams as RandomStreams
from pickle import HIGHEST_PROTOCOL
from six import BytesIO
try:
    from pickle import DEFAULT_PROTOCOL
except ImportError:
    DEFAULT_PROTOCOL = HIGHEST_PROTOCOL

__author__ = 'jan'

srng = RandomStreams()
theano.config.compute_test_value = 'warn'
floatX = theano.config.floatX


def as_floatX(x):
    return np.asarray(x, dtype=theano.config.floatX)


class Bunch(dict):
    def __init__(self, *args, **kwargs):
        super(Bunch, self).__init__(*args, **kwargs)
        self.__dict__ = self


class ignore_no_test_value:
    def __init__(self):
        pass

    def __enter__(self):
        self.compute_test_value = theano.config.compute_test_value
        theano.config.compute_test_value = 'ignore'

    # noinspection PyUnusedLocal
    def __exit__(self, type, value, traceback):
        theano.config.compute_test_value = self.compute_test_value


def init_weights(shape, name="w"):
    return theano.shared(as_floatX(np.random.randn(*shape) / shape[0] ** 0.5), name=name)


def init_bias(shape, name="b"):
    return theano.shared(as_floatX(np.zeros(*shape)), name=name)


def dropout(x, p_use=1.):
    if p_use == 1.:
        return x
    else:
        with ignore_no_test_value():
            bernoulli_vars = srng.uniform(x.shape, 0, 1) <= p_use
        x *= bernoulli_vars
        return x / p_use


def RMSprop(cost, params, lr=0.001, rho=0.9, epsilon=1e-6):
    grads = T.grad(cost=cost, wrt=params)
    updates = []
    for p, g in zip(params, grads):
        acc = theano.shared(p.get_value() * 0., name="acc", broadcastable=p.broadcastable)
        acc_new = rho * acc + (1 - rho) * g ** 2
        gradient_scaling = T.sqrt(acc_new + epsilon)
        g = g / gradient_scaling
        updates.append((acc, acc_new))
        updates.append((p, p - lr * g))
    return updates


def adam(cost, params, alpha=0.001, beta1=0.9, beta2=0.999, epsilon=1e-8):
    """Kingma, D., and Ba, J. (2014). Adam: A Method for Stochastic Optimization. arXiv1412.6980 [Cs] 1-15."""
    grads = T.grad(cost=cost, wrt=params)
    updates = []
    t = theano.shared(as_floatX(1), name='time step')
    updates.append((t, t + 1))
    for p, g in zip(params, grads):
        m_old = theano.shared(p.get_value() * 0., name="gradient moving average", broadcastable=p.broadcastable)
        m = beta1 * m_old + (1 - beta1) * g
        v_old = theano.shared(p.get_value() * 0., name="squared gradient moving average", broadcastable=p.broadcastable)
        v = beta1 * v_old + (1 - beta1) * g ** 2
        updates.append((m_old, m))
        updates.append((v_old, v))
        m /= (1 - beta1 ** t)  # bias correction
        v /= (1 - beta2 ** t)
        updates.append((p, p - alpha * m / (T.sqrt(v) + epsilon)))
    return updates


def ichunks(gen, size):
    """Yield successive `size`-sized chunk iterators from iterable `gen`."""
    iterator = iter(gen)
    for first in iterator:
        yield it.chain([first], it.islice(iterator, size - 1))


def chunks(gen, size):
    """Yield successive `size`-sized chunks from iterable `gen`."""
    return map(list, ichunks(gen, size))


def do_chunked(f, args_chunked, other_args, chunk_size):
    return np.vstack((f(*([x[i_chunk] for x in args_chunked] + other_args))
                      for i_chunk in chunks(range(args_chunked[0].shape[0]), chunk_size)))


def identity(x):
    return x


class DataSet(object):
    def __init__(self, x1d, target, index=None, k=0):
        self.x1d = as_floatX(x1d)
        self.target = target
        self.n_samples = target.shape[0]
        self.k = k
        kf = KFold(n_splits=10, shuffle=False, random_state=1)
        self.i_train, self.i_test = next(it.islice((kf.split(self.x1d, self.target, index)), self.k, self.k+1))
        self.n_train = len(self.i_train)
        self.n_test = len(self.i_test)

        bak = np.get_printoptions()
        np.set_printoptions(edgeitems=3, infstr='inf', linewidth=75, nanstr='nan', precision=6, suppress=False,
                            threshold=10, formatter=None)
        self.hash = hashlib.md5(str(sorted(self.__dict__)).encode('utf-8')).hexdigest()
        np.set_printoptions(**bak)

def elu(x):
    return T.switch(x > 0, x, T.exp(x) - 1)

class PypYNN(object):
    @staticmethod
    def add_default_model_parameters(mp, data_set):
        if mp.get("n_nodes_hidden") is None:
            mp.n_nodes_hidden = [100, 100, 100]
        n_layers = len(mp.n_nodes_hidden) + 1
        if mp.get("p_use") is None:
            mp.p_use = [0.8] + [0.5] * (n_layers - 1)
        if mp.get("act_fun") is None:
            mp.act_fun = ["T.nnet.relu"] * (n_layers - 1) + ["lambda z: z"]
        mp.refeed_input = mp.get("refeed_input", False)
        mp.renormalize_initialisation = mp.get("renormalize_initialisation", False)
        if mp.get("name") is None:
            mp.name = "NoName"
        if data_set is not None:
            n_test_values = 1000
            mp.x1d_test_value = data_set.x1d[:n_test_values, :]
            mp.target_test_value = data_set.target[:n_test_values, :]

            # Normalization to yield good initialization and avoid numerical problems:
            mp.x1d_means = np.nanmean(data_set.x1d, 0, keepdims=True)
            mp.x1d_stds = np.nanstd(data_set.x1d, 0, keepdims=True)
            mp.x1d_stds[mp.x1d_stds == 0] = 1  # to avoid NaNs when one feature contains no information/is constant

            mp.target_means = np.nanmean(data_set.target, keepdims=True)  # treat all entropies the same
            mp.target_stds = np.nanstd(data_set.target, keepdims=True)
        return mp

    def __init__(self, mp, data_set=None):
        # noinspection PyTypeChecker
        mp = self.add_default_model_parameters(Bunch(mp if mp is not None else {}), data_set)
        n_layers = len(mp.n_nodes_hidden) + 1
        self.model_parameters = mp

        t = T.matrix(name='target', dtype=floatX)
        t.tag.test_value = mp.target_test_value
        t_scaled = (t - mp.target_means) / mp.target_stds

        x1d = T.matrix(name='X1D', dtype=floatX)
        x1d.tag.test_value = mp.x1d_test_value
        x1d_scaled = (x1d - mp.x1d_means) / mp.x1d_stds

        n_features_1d = x1d.tag.test_value.shape[1]
        n_nodes_out = t.tag.test_value.shape[1]

        x = x1d_scaled
        n_nodes = [n_features_1d] + mp.n_nodes_hidden + [n_nodes_out]
        p_use = {'train': mp.p_use, 'test': [1.] * n_layers}

        w = [init_weights((n_nodes[i] + (n_nodes[0] if mp.refeed_input and i > 0 else 0),
                           n_nodes[i + 1]),
                          "w_" + str(i + 1))
             for i in range(n_layers)]
        b = [init_bias((n_nodes[i + 1],), "b_" + str(i + 1)) for i in range(n_layers)]

        layers = {'train': [x], 'test': [x]}
        for key in layers.keys():
            for i in range(n_layers):
                tmp = dropout(layers[key][-1], p_use[key][i])
                if mp.refeed_input and i > 0:
                    tmp = T.concatenate([tmp, dropout(layers[key][0], p_use[key][0])], axis=1)
                if mp.renormalize_initialisation:  # we abuse the test values for weight initialization here:
                    test_activations = (T.dot(tmp, w[i]) + b[i]).tag.test_value
                    w[i].set_value(w[i].get_value()/np.std(test_activations, axis=0, keepdims=True))
                    b[i].set_value(b[i].get_value() - np.mean(test_activations, axis=0) /
                                   np.std(test_activations, axis=0))
                    # now, every node's activity will have mean 0, sd 1
                tmp = T.dot(tmp, w[i]) + b[i]
                tmp = eval(mp.act_fun[i])(tmp)
                layers[key].append(tmp)

        for layer in layers:
            assert (len(p_use[layer]) == n_layers)
            assert (len(layers[layer]) == n_layers + 1)
        assert (len(mp.act_fun) == n_layers)
        assert (len(w) == n_layers)
        assert (len(b) == n_layers)

        nans = T.isnan(t_scaled)
        fraction_nans = T.mean(nans, dtype=floatX)
        mse = {key: T.mean(T.switch(nans, as_floatX(0), T.sqr(layers[key][-1] - t_scaled))) / (1 - fraction_nans)
               for key in layers.keys()}

        # noinspection PyUnresolvedReferences
        def scale_back(y_unscaled):
            return y_unscaled * mp.target_stds + mp.target_means

        self.params = w + b

        eta = T.scalar("learning rate (eta)", dtype=floatX)
        eta.tag.test_value = 0.001
        updates = adam(mse['train'], self.params, alpha=eta)

        #max_norm:
        #for i in [sum([i*(u[0] == ww) for i, u in enumerate(updates)]) for ww in w]:
        #    max_norm = 3.5
        #    norms = T.sqrt(T.sum(T.sqr(updates[i][1]), axis=0))
        #    updates[i] = (updates[i][0], updates[i][1] / T.switch(T.gt(norms, max_norm), norms, as_floatX(1)))

        self.train = theano.function(inputs=[x1d, t, eta], outputs=mse['train'], updates=updates,
                                     allow_input_downcast=True)

        self.mse_ = theano.function(inputs=[x1d, t],
                                    outputs=mse['test'],
                                    allow_input_downcast=True)
        self.mse_with_dropout_ = theano.function(inputs=[x1d, t],
                                                 outputs=mse['train'],
                                                 allow_input_downcast=True)

        self.predict_ = theano.function(inputs=[x1d],
                                        outputs=scale_back(layers['test'][-1]),
                                        allow_input_downcast=True)
        self.predict_with_dropout_ = theano.function(inputs=[x1d],
                                                     outputs=scale_back(layers['train'][-1]),
                                                     allow_input_downcast=True)

        x1d_grad = T.grad(T.mean(layers['test'][-1]), x1d)
        x1d_scaled_grad = T.grad(T.mean(layers['test'][-1]), x1d_scaled)

        self.sensitivity_ = theano.function(inputs=[x1d], outputs=[x1d_grad, x1d_scaled_grad],
                                            allow_input_downcast=True)

        self.name = time.strftime("PyyPNN_%Y-%m-%d_%H-%M_") + mp.name + '_' + ''.join(
            random.choice(string.ascii_uppercase + string.digits) for _ in range(3))
        self.error_log = []
        self.learning_rate_log = []
        self.last_test_prediction = None
        self.last_test_error = None
        self.i = 0
        self.training_parameters = []

    def predict(self, x1d, batch_size=1000):
        return do_chunked(self.predict_, [x1d], [], chunk_size=batch_size)

    def prob_predict(self, x1d, n=5, batch_size=1000):
        y = [do_chunked(self.predict_with_dropout_, [x1d], [], chunk_size=batch_size) for _ in range(n)]
        y_mean = np.mean(y, axis=0)
        y_std = np.std(y, axis=0)
        return y_mean, y_std

    def sensitivity(self, x1d, batch_size=1000):
        tmp = (self.sensitivity_(x1d[i_test_chunk, :]) for
               i_test_chunk in chunks(range(x1d.shape[0]), batch_size))
        tmp = zip(*tmp)
        return [np.vstack(s) for s in tmp]

    def mse(self, x1d, t, batch_size=1000, with_dropout=False):
        (s, n) = np.sum(
            [[len(i_train_chunk) * (self.mse_with_dropout_ if with_dropout else self.mse_)(
                x1d[i_train_chunk], t[i_train_chunk]),
              len(i_train_chunk)] for i_train_chunk in chunks(range(x1d.shape[0]), batch_size)],
            axis=0)
        return s/n

    def rmse(self, x1d, t, batch_size=1000, with_dropout=False, n=None):
        if with_dropout:
            y = self.prob_predict(x1d, *({"n": n} if n is not None else {}), batch_size=batch_size)[0]
        else:
            y = self.predict(x1d, batch_size=batch_size)
        return np.sqrt(np.mean((y-t)**2))

    def do_train(self, data_set, tp=None, out_dir='../results'):
        if tp is None:
            tp = dict()
        tp = Bunch(tp)
        if tp.get("n_epochs") is None:
            tp.n_epochs = 1000
        if tp.get("train_batch_size") is None:
            tp.train_batch_size = 100
        if tp.get("pred_batch_size") is None:
            tp.pred_batch_size = 1000
        if tp.get("save_every") is None:
            tp.save_every = 10000
        if tp.get("print_every") is None:
            tp.print_every = 500
        if tp.get("test_every") is None:
            tp.test_every = 5000
        if tp.get("learning_rate") is None:
            tp.learning_rate = 0.001
        if tp.get("n_learning_rate_step_down") is None:
            tp.n_learning_rate_step_down = 2
        tp.data_set_hash = data_set.hash
        tp.data_set_k = data_set.k

        eta = tp.learning_rate

        print("Model parameters: ", self.model_parameters)
        print("training parameter: ", tp)
        self.training_parameters.append(tp)
        print("Theano profile FLAG: ", theano.config.profile)
        print("Theano floatX: ", theano.config.floatX)
        print("Theano device: ", theano.config.device)

        i_train = data_set.i_train
        i_test = data_set.i_test
        n_train = data_set.n_train
        x1d = data_set.x1d
        t = data_set.target

        n_iter = int(tp.n_epochs * n_train / tp.train_batch_size)

        train_error = np.nan
        last_test = np.nan

        start_time = time.time()
        print("start training")
        print("")
        for i in range(1, n_iter + 1):
            self.i += 1
            self_i_epochs = self.i * tp.train_batch_size / n_train
            if i % np.ceil((n_iter+1) / (tp.n_learning_rate_step_down + 0.5)) == 0:
                eta /= 10
            self.learning_rate_log.append((self.i * tp.train_batch_size / n_train, eta))

            selected = np.random.choice(i_train, size=tp.train_batch_size)
            error_while_training = self.train(x1d[selected],  t[selected], eta).tolist()
            self.error_log.append((self_i_epochs, error_while_training, "error_while_training"))

            if i == 1 or i % tp.test_every == 0 or i == n_iter:
                last_test = self_i_epochs
                self.last_test_error = self.mse(x1d[i_test], t[i_test], tp.pred_batch_size)
                self.error_log.append((self_i_epochs, self.last_test_error, "test_error"))
                self.last_test_prediction = {"epoch": self_i_epochs,
                                             "y": self.predict(x1d[i_test], tp.pred_batch_size),
                                             "t": t[i_test],
                                             "i_test": i_test}
                train_error = self.mse(x1d[i_train], t[i_train], tp.pred_batch_size)
                self.error_log.append((self_i_epochs, train_error, "train_error"))
            if tp.save_every is not np.nan and i == 1 or i % tp.save_every == 0 or i == n_iter:
                self.save_model(out_dir)
            if i == 1 or i % tp.print_every == 0 or i == n_iter:
                print('\r', end='')
                print_(("Epoch {:>5.2}: iteration {:>6} of {:>6}; current eta: {:>5}; ({:<10s} so far, {:<10s} to go)" +
                        " current errors: while learning: {:>5.3},  train: {:>5.3}," +
                        " test: {:>5.3} (latter two at epoch {:>5.2})"
                        ).format(self.i * tp.train_batch_size / n_train, i, n_iter, eta,
                                 str(datetime.timedelta(seconds=time.time() - start_time)),
                                 str(datetime.timedelta(seconds=(time.time() - start_time) / i) * (n_iter - i)),
                                 error_while_training, train_error, self.last_test_error, last_test),
                       end='' if (i != n_iter) else '\n',
                       flush=True)

        print("done. runtime: {}".format(str(datetime.timedelta(seconds=time.time() - start_time))))

    def __getstate__(self):
        return {param.name: param.get_value() for param in self.params}, self.training_parameters, \
               self.model_parameters, self.name, self.i, self.error_log, self.learning_rate_log, \
               self.last_test_prediction, self.last_test_error

    def __setstate__(self, state):
        params, training_parameters, model_parameters, name, i, error_log, learning_rate_log, last_test_prediction, \
            last_test_error = state
        self.__init__(model_parameters)
        self.training_parameters = training_parameters
        self.name = name + "'"
        self.i = i
        self.error_log = error_log
        self.learning_rate_log = learning_rate_log
        self.last_test_prediction = last_test_prediction
        self.last_test_error = last_test_error
        for param in self.params:
            param.set_value(params[param.name])

    def save_model(self, out_dir, protocol=DEFAULT_PROTOCOL):
        folder = os.path.join(out_dir, self.name)
        try:
            os.makedirs(folder)
            print("Results go into: ", folder)
        except OSError:
            if not os.path.isdir(folder):
                raise
        f = open(os.path.join(folder, 'iteration_{:=06d}.zip'.format(self.i)), 'wb')
        theano.misc.pkl_utils.dump(self, f, protocol=protocol)
        f.close()

    @staticmethod
    def load_model(file_path):
        f = open(file_path, 'rb')
        self = theano.misc.pkl_utils.load(f)
        f.close()
        return self
