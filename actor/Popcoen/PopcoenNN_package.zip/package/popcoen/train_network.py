from __future__ import print_function
import numpy as np
import os
import pkg_resources

from PyyPNN import PypYNN, DataSet

np.seterr(all='warn')
np.set_printoptions(threshold=10)

data_folder = pkg_resources.resource_filename('popcoen', 'data/')
out_dir = "."

x = np.load(os.path.join(data_folder, "x_test.npy"))
x_cols = np.array([line.rstrip('\n') for line in open(os.path.join(data_folder, 'x_colnames.txt'))])
y = np.load(os.path.join(data_folder, "y_test.npy"))

replace_nan_with_0 = True
if replace_nan_with_0:
    y[np.isnan(y)] = 0

idx = np.cumsum(np.concatenate([[True], np.all(np.diff(x[:, :8], axis=0), axis=1)]))
data_set = DataSet(x, y, index=idx, k=0)


n_hidden = 5
model_parameter = dict(
    n_nodes_hidden=[100] * n_hidden,
    p_use=[0.90] + [0.70] * n_hidden,
    refeed_input=True,
    name="popcoen_v1",
    act_fun=["elu"] * n_hidden + ["lambda z: z"],
    renormalize_initialisation=True
    )

model = PypYNN(model_parameter, data_set)

training_parameters = dict(
    replace_nan_with_0=replace_nan_with_0,  # for documentation only
    n_epochs=200,
    train_batch_size=200,
    learning_rate=0.0005,
    n_learning_rate_step_down=2,
    test_every=500)
model.do_train(data_set, training_parameters, out_dir=out_dir)
print("Final validation error: ", model.last_test_error)