from .PyyPNN import *
from . import PyyPNN
import sys
sys.modules['PyyPNN'] = PyyPNN
from .example_prediction import predict
from .example_prediction import test
