from __future__ import print_function
import numpy as np
import os
import pkg_resources
from .PyyPNN import PypYNN, as_floatX
model_file = pkg_resources.resource_filename('popcoen', 'data/net.zip')

# Load model
model = PypYNN.load_model(model_file)

# predict with popcoen 1.0
def predict(x):
    if model.training_parameters[-1].replace_nan_with_0:
        x[np.isnan(x)] = 0
    return model.predict(as_floatX(x), batch_size=model.training_parameters[-1].train_batch_size)[:,0]

# Run example prediction on test set
def test():
    data_folder = pkg_resources.resource_filename('popcoen', 'data/')
    x = np.load(os.path.join(data_folder, "x_test.npy"))
    x_cols = np.array([line.rstrip('\n') for line in open(os.path.join(data_folder, 'x_colnames.txt'))])
    y = np.load(os.path.join(data_folder, "y_test.npy"))

    print("Correlation coefficient: " + str(np.corrcoef(y, predict(x))[0, 1]))


